﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;

namespace PracticeSpace.Models
{
    public class StudentDto
    {
        [ValidateNever]
        public int Id { get; set; }

        [Required(ErrorMessage ="Student name is required")]
        public string StudentName { get; set; }
        [Required(ErrorMessage = "Please enter the valid email address")]

        [EmailAddress]
        public string Email { get; set; }

        public string Address { get; set; }
    }
}
