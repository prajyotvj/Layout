﻿namespace PracticeSpace.Models
{
    public class CollegeRepository
    {
        public static List<Student> Students = new List<Student>()
        {
                new Student
                {
                    Id = 1,
                    StudentName = "Prajyot",
                    Email = "prajyotjadhav@gmail.com",
                    Address = "Nashik"
                },
                new Student
                {
                    Id = 2,
                    StudentName = "Ruturaj",
                    Email = "ruturaj@gmail.com",
                    Address = "Nashik"
                },
                new Student
                {
                    Id = 3,
                    StudentName = "Abhipray",
                    Email = "abhiray@gmail.com",
                    Address = "Nashik"
                },
                new Student
                {
                    Id = 4,
                    StudentName = "Chaitanya",
                    Email = "chaitanya@gmail.com",
                    Address = "Jalgaon"
                }
        };

    }
}
