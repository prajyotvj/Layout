﻿namespace PracticeSpace.MyLogging
{
    public class LogToFile
    {
        public void Log(string message)
        {
            Console.WriteLine(message);
            Console.WriteLine("LogtoDB");
        }
    }
}
