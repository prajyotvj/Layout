﻿namespace PracticeSpace.MyLogging
{
    public class LogToServerMemory
    {
        public void Log(string message)
        {
            Console.WriteLine(message);
            Console.WriteLine("Logto Server memory");
        }
    }
}
