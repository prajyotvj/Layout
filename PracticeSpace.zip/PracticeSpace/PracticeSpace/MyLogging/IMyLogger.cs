﻿namespace PracticeSpace.MyLogging
{
    public interface IMyLogger
    {
        void Log(string message);
    }
}
