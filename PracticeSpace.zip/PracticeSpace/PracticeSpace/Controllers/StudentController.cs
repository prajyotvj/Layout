﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using PracticeSpace.Models;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography.Xml;

namespace PracticeSpace.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public class StudentController : ControllerBase
    {
        [HttpGet]
        [Route("All",Name = "GetAllStudents")]
        public IActionResult GetStudentList()
        {

            /*foreach (var item in CollegeRepository.Students)
             {
                 StudentDto obj = new StudentDto()
                 {
                     Id = item.Id,
                     StudentName = item.StudentName,
                     Email = item.Email,
                     Address = item.Address,

                 };

                 students.Add(obj);
             }*/
            var students = CollegeRepository.Students.Select(s => new StudentDto()  
            {
                Id = s.Id,
                StudentName = s.StudentName,
                Email = s.Email,
                Address = s.Address

            });
            return Ok(students);
        }


        [HttpGet("{id:int}",Name= "GetStudentById")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult GetStudentById(int id)
        {
            if(id <= 0)
            {
                return BadRequest();
            }
            Student student = CollegeRepository.Students.FirstOrDefault(n => n.Id == id);

            var StudentDto = new StudentDto()
            {
                Id = student.Id,
                StudentName = student.StudentName,
                Email = student.Email,
                Address = student.Address,
            };

            if (student== null)
            {
                return NotFound("Student Not Found");
            }
            return Ok(student);

        }

        [HttpGet("{name:alpha}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult GetStudentByName(string name)
        {
            if (String.IsNullOrEmpty(name))
            {
                return BadRequest();
            }

            Student student = CollegeRepository.Students.FirstOrDefault(n => n.StudentName == name);

            if (student == null)
            {
                return NotFound("Student Not Found");
            }

            return Ok(student);

        }

        [HttpPost]
        [Route("Create")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult CreateStudent( [FromBody] StudentDto model)
        {
            if(model == null)
            {
                return BadRequest();
            }
            int newId = CollegeRepository.Students.LastOrDefault().Id + 1;
            Student student = new Student
            {
                Id = newId,
                StudentName = model.StudentName,
                Address = model.Address,
                Email = model.Email,
            };
            CollegeRepository.Students.Add(student);

            model.Id = student.Id;
            return CreatedAtRoute("GetStudentById", new { id = model.Id}, model);
            //return Ok(model);

        }

        [HttpDelete("/DeleteStudentById/{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public ActionResult<bool> DeleteStudentById(int id)
        {
            if (id <= 0)
            {
                return BadRequest();
            }
            Student studentList = CollegeRepository.Students.FirstOrDefault(n => n.Id == id);

            if (studentList == null)
            {
                return NotFound("Student Not Found");
            }

            CollegeRepository.Students.Remove(studentList);
            return Ok(true);
        }

        [HttpPut]
        [Route("Update")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult UpdateStudent([FromBody]StudentDto model)
        {
            if(model == null || model.Id <= 0)
            {
                return BadRequest();
            }

            var existingStudent = CollegeRepository.Students.FirstOrDefault(n => n.Id == model.Id);

            existingStudent.StudentName = model.StudentName;
            existingStudent.Email = model.Email;
            existingStudent.Address = model.Address;

            return Ok(existingStudent);
        }


        [HttpPut]
        [Route("{id:int}/UpdatePartial")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult UpdateStudentPartial(int id, [FromBody] JsonPatchDocument<Student> patchDocument)
        {
            if (patchDocument == null || id <= 0)
            {
                return BadRequest();
            }

            var existingStudent = CollegeRepository.Students.Where(n => n.Id == id).FirstOrDefault();

            if (existingStudent == null)
                return NotFound();

            //var studentDTO = new StudentDto()
            //{
            //    Id = existingStudent.Id,
            //    StudentName = existingStudent.StudentName,
            //    Email = existingStudent.Email,
            //    Address = existingStudent.Address,
            //};

            var student = new Student()
            {
                Id = existingStudent.Id,
                StudentName = existingStudent.StudentName,
                Email = existingStudent.Email,
                Address = existingStudent.Address,
            };

            patchDocument.ApplyTo(student, ModelState);

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            existingStudent.StudentName = student.StudentName;
            existingStudent.Email = student.Email;
            existingStudent.Address = student.Address;

            return NoContent();
        }

    }
}
